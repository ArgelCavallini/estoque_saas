<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('menus', function (Blueprint $table) {
        if (!Schema::hasColumn('menus', 'permissao_id')) {
            $table->foreignId('permissao_id')
                ->nullable()
                ->constrained('permissoes')
                ->nullOnDelete();
        }
    });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('menus', function (Blueprint $table) {
            if (Schema::hasColumn('menus', 'permissao_id')) {
                $table->dropForeign(['permissao_id']);
                $table->dropColumn('permissao_id');
            }
        });
    }
};
